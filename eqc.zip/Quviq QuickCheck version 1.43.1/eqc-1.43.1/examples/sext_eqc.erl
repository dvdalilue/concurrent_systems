-file("eqc-1.43.1/examples/sext_eqc.erl", 0).
%% -*- erlang-indent-level: 4; indent-tabs-mode: nil -*-
%%==============================================================================
%% Copyright 2014-16 Ulf Wiger
%%
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%% http://www.apache.org/licenses/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.
%%==============================================================================

-module(sext_eqc).

-include_lib("eqc/include/eqc.hrl").
-include("../include/eqc_tree.hrl").
-compile([export_all, nowarn_export_all]).
-compile({parse_transform,eqc_parallelize}).



prop_sort() ->
    ?FORALL([T1, T2], erlang_terms(2),
            begin
                {P1,P2} = {sext:encode(T1), sext:encode(T2)},
                {SB1,SB2} = {sext:encode_sb32(T1), sext:encode_sb32(T2)},
                {H1,H2} = {sext:encode_hex(T1), sext:encode_hex(T2)},
                Comp = comp_i(T1,T2),
                measure(term_sizes, size(term_to_binary({T1, T2})),
                conjunction([{encode, equals(comp(P1,P2), Comp)},
                             {encode_sb32, equals(comp(SB1,SB2), Comp)},
                             {hex, equals(comp(H1,H2), Comp)}
                            ]))
            end).

prop_encode() ->
    ?FORALL(T, erlang_term(),
            conjunction([{encode, equals(sext:decode(sext:encode(T)), T)},
                         {encode_sb32, equals(sext:decode_sb32(sext:encode_sb32(T)), T)},
                         {encode_hex, equals(sext:decode_hex(sext:encode_hex(T)), T)}
                        ])).

prop_encode_legacy() ->
    ?FORALL(T, erlang_term(),
            equals(sext:decode(sext:encode(T, true)), T)).


%% Why, if this is the same, does the function prefix exist?
%% Answer: for terms with patterns in it (which we do not generate as erlang_term).
%% Partial-decoding a whole term should give the term back
prop_prefix_equiv() ->
    ?FORALL(T, erlang_term(),
            begin
                Enc = sext:encode(T),
                conjunction([{prefix, equals(sext:prefix(T), Enc)},
                             {no_rest, equals(sext:partial_decode(Enc), {full, T, <<>>})}
                            ])
            end).

%% Partial-decoding a prefix should give a _comparable_ prefix back
prop_partial_decode() ->
    ?FORALL(Pat, wild_term(),
            begin
                {Prf, Bool} = 
                    case sext:partial_decode(sext:prefix(Pat)) of
                        {full, _, _} -> {full, true};
                        {partial, Dec, Rest} ->
                            {partial, comp_pat(Dec, Pat) andalso Rest == <<>>}
                    end,
                collect(Prf, 
                        ?WHENFAIL(eqc:format("Decoding prefix = ~p\n",[sext:partial_decode(sext:prefix(Pat))]),
                                  Bool))
            end).

%% A sext term followed by something not sext-encoded
prop_partial_decode_plus1() ->
    ?FORALL({T, Extra}, {erlang_term(), binary()},
            begin
                Enc = sext:encode(T),
                equals({full, T, Extra},
                    sext:partial_decode(<<Enc/binary, Extra/binary>>))
            end).

%% A sext prefix followed by something not sext-encoded
prop_partial_decode_plus2() ->
    ?FORALL(Pat, wild_pat(),
            begin
                Pfx = sext:prefix(Pat),
                case sext:partial_decode(<<Pfx/binary, "foo">>) of
                    {full, Dec, <<"foo">>} ->
                        Dec == Pat;
                    {partial, Dec, <<"foo">>} ->
                        comp_pat(Dec, Pat)
                end
            end).

wild_pat() ->
    ?LET({T,W}, {?SUCHTHAT(Tp, prefixable_term(),
                           positions(Tp) > 0),wild()},
         ?LET(P, choose(1, positions(T)),
              make_wild(T, P, W))).

comp_pat(X, X) -> true;
comp_pat(A, B) when is_tuple(A), is_tuple(B), size(A) == size(B) ->
    comp_pat_l(tuple_to_list(A), tuple_to_list(B));
comp_pat(Dec, Pat) when is_list(Dec), is_list(Pat) ->
    comp_pat_l(Dec, Pat);
comp_pat(A, B) ->  % A: decoded; B: prefix
    case {is_wild(A), is_wild(B)} of
        {true, true} -> true;
        {true, false} ->
            case B of
                [H|_] ->
                    %% This is because the decoded prefix of [] and ['_'|'_']
                    %% are both '_'
                    is_wild(H);
                _ -> false
            end;
        _ ->
            false
    end.

comp_pat_l([H1|T1], [H2|T2]) ->
    case is_wild(H1) of
        true -> true;
        false ->
            case comp_pat(H1, H2) of
                true  -> comp_pat_l(T1, T2);
                false -> false
            end
    end;
comp_pat_l([], []) -> true;
comp_pat_l(A, _) ->
    is_wild(A).


prop_is_prefix1() ->
    ?FORALL({T,W}, {?SUCHTHAT(Tp, prefixable_term(),
                              positions(Tp) > 0),wild()},
            ?LET(P, choose(1, positions(T)),
                 begin
                     Pfx = sext:prefix(make_wild(T,P,W)),
                     is_prefix(Pfx, sext:encode(T))
                 end)).

prop_is_prefix2() ->
    ?FORALL({T,W}, {?SUCHTHAT(Tp, prefixable_term(),
                              positions(Tp) > 2), wild()},
            ?LET(P, choose(2, positions(T)),
                 begin
                     {Pfx1,Pfx2} = {sext:prefix(make_wild(T,P,W)),
                                    sext:prefix(make_wild(T,P-1,W))},
                     is_prefix(Pfx2, Pfx1)
                 end)).

prop_is_prefix_hex1() ->
    ?FORALL({T,W}, {?SUCHTHAT(Tp, prefixable_term(),
                              positions(Tp) > 0),wild()},
            ?LET(P, choose(1, positions(T)),
                 begin
                     Pfx = sext:prefix_hex(make_wild(T,P,W)),
                     is_prefix(Pfx, sext:encode_hex(T))
                 end)).

prop_is_prefix_hex2() ->
    ?FORALL({T,W}, {?SUCHTHAT(Tp, prefixable_term(),
                              positions(Tp) > 2), wild()},
            ?LET(P, choose(2, positions(T)),
                 begin
                     {Pfx1,Pfx2} = {sext:prefix_hex(make_wild(T,P,W)),
                                    sext:prefix_hex(make_wild(T,P-1,W))},
                     is_prefix(Pfx2, Pfx1)
                 end)).

prop_non_proper_sorts() ->
    ?FORALL(N, choose(2,6), 
    ?FORALL([T | L], erlang_terms(N),
            begin
                List = [{L, 1},
                        {L ++ T, 2},
                        {L ++ [T], 3}],
                Encoded = [{sext:encode(A),B} || {A,B} <- List],
                Sorted1 = lists:keysort(1, List),
                Sorted2 = lists:keysort(1, Encoded),
                [I || {_,I} <- Sorted1]
                    == [J || {_,J} <- Sorted2]
            end)).

comp(A,B) when A == B, A =/= B ->
    %% can only happen when either is a float and the other an int
    IsMore = if A < 0 ->
                     is_float(B);
                true ->
                     is_float(A)
             end,
    case IsMore of
        true -> more;
        false -> less
    end;
comp(A,B) when A < B -> less;
comp(A,A) -> equal;
comp(_,_) -> more.

comp_i(Ta, Tb) when is_tuple(Ta), is_tuple(Tb),
                    tuple_size(Ta) == tuple_size(Tb) ->
    comp_l(tuple_to_list(Ta), tuple_to_list(Tb));
comp_i(La, Lb) when is_list(La), is_list(Lb) ->
    comp_l(La, Lb);
comp_i(A, B) ->
    comp(A, B).

comp_l([] , [] ) -> equal;
comp_l([] , [_|_] ) -> less;
comp_l([_|_] , [] ) -> more;
comp_l([Ha|Ta],[Hb|Tb]) ->
    case comp(Ha, Hb) of
        equal ->
            comp_l(Ta, Tb);
        Other ->
            Other
    end;
comp_l(A, B) -> % A or B was an improper list
    comp_i(A, B).

is_prefix(A, B) ->
    Sz = byte_size(A),
    binary:longest_common_prefix([A,B]) == Sz.

prop_distribution() ->
    ?FORALL(T1, erlang_term(),
            begin
                Size = size(term_to_binary(T1)),
                measure(sizes, Size,
                eqc:check_distribution(include_large_terms, 0.1, Size > 450,
                eqc:check_distribution(term_size, 0.25, Size > 200, true)))
            end).                


anatom() ->
    oneof([a,b,c,aa,bb,cc]).

prefixable_term() ->
    ?LET(N, choose(1, 5),
         ?LET(Ts, erlang_terms(N), 
              oneof([Ts, list_to_tuple(Ts)]))).

wild_term() ->
    with_parameter(wild, true, erlang_term()).


prop_positions() ->
    ?FORALL(T, prefixable_term(),
            begin 
                Ps = positions(T),
                measure(positions, Ps,
                        eqc:check_distribution(several_positions, 0.8, Ps > 1, true))
            end).

positions(T) ->
    positions(T, 0).

positions(T, Acc) when is_tuple(T) ->
    positions(tuple_to_list(T), Acc);
positions([H|T], Acc) ->
    positions(T, positions(H) + Acc);
positions([], Acc) ->
    Acc;
positions(_, Acc) ->
    Acc+1.

is_wild('_') -> true;
is_wild(A) when is_atom(A) ->
    case atom_to_list(A) of
        "\$" ++ Is ->
            try _ = list_to_integer(Is),
                  true
            catch
                error:_ ->
                    false
            end;
        _ ->
            false
    end;
is_wild(_) ->
    false.

make_wild(T, P, W) when P > 0 ->
    if is_tuple(T) ->
            {Res,_} = make_wild1(tuple_to_list(T), P, W, []),
            list_to_tuple(Res);
       is_list(T) ->
            {Res,_} = make_wild1(T, P, W, []),
            Res
    end.

make_wild1(L, 0, _, Acc) ->
    {lists:reverse(Acc) ++ L, 0};
make_wild1(T, P, W, Acc) when not(is_list(T)) ->
    if P == 1 ->
            {lists:reverse(Acc) ++ W, 0};
       true ->
            {lists:reverse(Acc) ++ T, P-1}
    end;
make_wild1([_|T], 1, W, Acc) ->
    {lists:reverse(Acc) ++ [W|T], 0};
make_wild1([H|T], P, W, Acc) ->
    if is_tuple(H) ->
            {H1,P1} = make_wild1(tuple_to_list(H), P, W, []),
            make_wild1(T, P1, W, [list_to_tuple(H1)|Acc]);
       is_list(H) ->
            {H1,P1} = make_wild1(H, P, W, []),
            make_wild1(T, P1, W, [H1|Acc]);
       true ->
            make_wild1(T, P-1, W, [H|Acc])
    end;
make_wild1([], P, _W, Acc) ->
    {lists:reverse(Acc), P}.

wild() ->
    oneof(['_','$1','$9999']).

lists_replace(L, P, V) when P > 0, P =< length(L) ->
    {L1, [_|L2]} = lists:split(P-1, L),
    L1 ++ [V] ++ L2.

%%% ------------------ Using tree generator instead ------------------------------


prop_term_to_binary() ->
    ?FORALL([T1,T2], erlang_terms(2),
            ?WHENFAIL(eqc:format("T1 ~s T2\nB1\nB2\n", [ "\u2264", term_to_binary(T1), term_to_binary(T2)]),  
                      if T1 =< T2 -> term_to_binary(T1) =< term_to_binary(T2); 
                         T1 > T2  -> term_to_binary(T1) > term_to_binary(T2)
                      end)).

erlang_term_gen() ->
  ?LET(Wild, parameter(wild, false),
       tree(?MODULE, #{depth => 0,
                       pids => lists:nthtail(10, erlang:processes()),
                       refs => [ erlang:make_ref() || _ <- lists:seq(1,10)],
                       wild => Wild}, term)).

erlang_term() ->
    ?LET(Expr, erlang_term_gen(), eval(Expr)).

erlang_terms(N) ->
    ?LET(Exprs,
         frequency([{10, ?LET(Expr, erlang_term_gen(),  lists:duplicate(N, Expr))},
                    {1, vector(N, erlang_term_gen())}]),
         [ eval(E) || E<-Exprs ]).

-define(MAX_DEPTH, 3).

grammar(Env = #{ depth := D, pids := Pids, refs := Refs }) ->
  Term   = nonterminal(term),
  Simple = nonterminal(simple),
  Deeper = fun(E) -> when_t(D < ?MAX_DEPTH,
                     env_t(Env#{ depth := D + 1 }, E)) end,
  #{ term =>
       choice_t([ {call, eqc_gen, Simple, []},
                  {call, eqc_gen, elements, [Pids]},
                  {call, eqc_gen, elements, [Refs]},
                  anatom(),  %% fix later with more choice!
                  Deeper({call, eqc_gen, list, [Term]}),
                  Deeper({call, eqc_gen, map, [Term, Term]}),
                  {call, erlang, list_to_tuple, [list_t(0, 3, Term)]},
                  {call, ?MODULE, cons, [Term, Term]}
                ]),
     simple =>
         choice_t([int, largeint, real, Deeper(binary), Deeper(bitstring)])
   }.

shrink_tree(term, {call, erlang, list_to_tuple, [[]]}) -> [{}];
shrink_tree(_, X) when is_float(X) -> [round(X)];
shrink_tree(_, _) -> [].

cons(X, Y) -> [X | Y].

prop_fast() ->
    ?FORALL(T1, erlang_term_gen(),
            begin
                Size = size(term_to_binary(T1)),
                measure(sizes, Size, true)
            end).


