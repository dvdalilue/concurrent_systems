-file("eqc-1.43.1/examples/eqc_cpp/overloading/eqc_cpp_overloading_eqc.erl", 0).
%%% File        : eqc_cpp_overloading_eqc.erl
%%% Author      : Hans Svensson
%%% Description :
%%% Created     : 14 Aug 2017 by Hans Svensson
-module(eqc_cpp_overloading_eqc).

-compile([export_all, nowarn_export_all]).

-file("eqc-1.43.1/examples/eqc_cpp/overloading/eqc_cpp_overloading_eqc.erl", 9).

-include_lib("eqc/include/eqc.hrl").
-include_lib("eqc/include/eqc_statem.hrl").

-define(PATH, "../examples/eqc_cpp/overloading/").
-define(SWG_FILE, ?PATH ++ "overloading.swg").

%% -- State ------------------------------------------------------------------

initial_state() -> #{}.

%% -- Operations -------------------------------------------------------------

%% --- new ---
new_args(S) -> [next_tag(S), int()].

new_pre(S) -> length(objs(S)) < 4.

new(_Tag, I) -> ovld:'Ovld_new'(I).

new_next(S, O, [T, I]) ->
  update_s(update_s(S, objs, T, O), vals, T, I).

%% --- Operation: bin_plus ---
bin_plus_pre(S) -> objs(S) =/= [].

bin_plus_args(S) ->
  [gen_obj(S), gen_obj_or_const(S)].

bin_plus_pre(S, [O1, O2]) ->
  is_obj(O1, S) andalso is_obj(O2, S).

bin_plus(O1, O2) ->
  ovld:'Ovld+'(get_obj(O1), get_obj(O2)).

bin_plus_post(S, [O1, O2], Res) ->
  eq(value_of(Res), value_of(O1, S) + value_of(O2, S)).

%% --- Operation: cmp ---
cmp_pre(S) -> objs(S) =/= [].

cmp_args(S) ->
  [gen_obj(S), gen_obj_or_const(S)].

cmp_pre(S, [O1, O2]) ->
  is_obj(O1, S) andalso is_obj(O2, S).

cmp(O1, O2) ->
  ovld:'Ovld=='(get_obj(O1), get_obj(O2)).

cmp_post(S, [O1, O2], Res) ->
  eq(Res, value_of(O1, S) == value_of(O2, S)).

%% --- Operation: pre_inc ---
pre_inc_pre(S) -> objs(S) =/= [].

pre_inc_args(S) ->
  [gen_obj(S)].

pre_inc_pre(S, [O1]) ->
  is_obj(O1, S).

pre_inc(O1) ->
  ovld:'Ovld++'(get_obj(O1)).

pre_inc_next(S, _Value, [O = {Tag, _}]) ->
  update_s(S, vals, Tag, value_of(O, S) + 1).

pre_inc_post(S, [O1], Res) ->
  eq(value_of(Res), value_of(O1, S) + 1).

%% --- Operation: post_inc ---
post_inc_pre(S) -> objs(S) =/= [].

post_inc_args(S) ->
  [gen_obj(S)].

post_inc_pre(S, [O1]) ->
  is_obj(O1, S).

post_inc(O1) ->
  ovld:'Ovld++'(get_obj(O1), 0).

post_inc_next(S, _Value, [O = {Tag, _}]) ->
  update_s(S, vals, Tag, value_of(O, S) + 1).

post_inc_post(S, [O1], Res) ->
  eq(value_of(Res), value_of(O1, S)).

%% --- Operation: assign ---
assign_pre(S) -> objs(S) =/= [].

assign_args(S) ->
  [gen_obj(S), gen_obj_or_const(S)].

assign_pre(S, [O1, O2]) ->
  is_obj(O1, S) andalso is_obj(O2, S).

assign(O1, O2) ->
  ovld:'Ovld='(get_obj(O1), get_obj(O2)).

assign_next(S, _Value, [{Tag, _}, O2]) ->
  update_s(S, vals, Tag, value_of(O2, S)).

assign_post(S, [_O1, O2], Res) ->
  eq(value_of(Res), value_of(O2, S)).

%% --- Operation: indirection ---
indirection_pre(S) -> objs(S) =/= [].

indirection_args(S) ->
  [gen_obj(S)].

indirection_pre(S, [O1]) ->
  is_obj(O1, S).

indirection(O1) ->
  ovld:'Ovld*'(get_obj(O1)).

indirection_post(S, [O1], Res) ->
  eq(Res, value_of(O1, S)).


%% -- Property ---------------------------------------------------------------

prop_ok() ->
  ?SETUP(fun() -> start(), fun() -> ok end end,
  ?FORALL(Cmds, commands(?MODULE),
  begin
    eqc_c:restart(),
    {H, S, Res} = run_commands(Cmds),
    check_command_names(Cmds,
      measure(length, commands_length(Cmds),
        pretty_commands(?MODULE, Cmds, {H, S, Res},
                        Res == ok)))
  end)).

start() ->
  CPP = eqc_c_tools:find_executable("C++ compiler", cpp, [], "g++"),
  TempDir   = eqc_c_tools:temp_dir(),
  cpp_compile(CPP, TempDir, ?PATH, "overloading"),

  eqc_cpp:start(ovld, [{swig_file, ?SWG_FILE},
                       {additional_files, [filename:join(TempDir, "overloading.o")]},
                       {cflags, "-I" ++ ?PATH}]).

%% -- Helper functions -------------------------------------------------------

objs(S) -> maps:get(objs, S, []).

next_tag(S) ->
  list_to_atom("o" ++ integer_to_list(length(objs(S)) + 1)).

update_s(S, Fld, Key, Val) ->
  S#{ Fld => lists:keystore(Key, 1, maps:get(Fld, S, []), {Key, Val}) }.

gen_obj(#{ objs := Objs }) ->
  elements([ O || O <- Objs ]).

gen_obj_or_const(S) ->
  weighted_default({1, int()}, {1, gen_obj(S)}).

get_obj({_, OPtr}) ->
  OPtr;
get_obj(Val) ->
  ovld:'Ovld_new'(Val).

value_of(OPtr) ->
  ovld:'Ovld_get_a'(OPtr).

value_of({Tag, _}, #{ vals := Vals }) ->
  {_, V} = lists:keyfind(Tag, 1, Vals),
  V;
value_of(X, _) ->
  X.

is_obj({Tag, _}, #{ objs := Objs }) ->
  lists:keymember(Tag, 1, Objs);
is_obj(_, _) ->
  true.

cpp_compile(CPP, TempDir, Path, FileBase) ->
  Outp = os:cmd(CPP ++ " -c " ++ filename:join(Path, FileBase ++ ".cpp") ++
                " -o " ++ filename:join(TempDir, FileBase ++ ".o")),
  case filelib:is_file(filename:join(TempDir, FileBase ++ ".o")) of
    true  ->
      io:format("Compiled: ~s.o\n", [FileBase]);
    false ->
      io:format("In: ~p\n", [file:get_cwd()]),
      io:format("Failed to compile ~s.o\n\n~s\n", [FileBase, Outp]),
      error(compilation_failed)
  end.


