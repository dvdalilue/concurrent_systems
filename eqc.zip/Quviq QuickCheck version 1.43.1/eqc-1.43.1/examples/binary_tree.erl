-file("eqc-1.43.1/examples/binary_tree.erl", 0).
-module(binary_tree).

-include_lib("eqc/include/eqc.hrl").
-import(eqc_tree, [nonterminal/1, choice/1]).

-export([grammar/1, operator_tree/0]).

tree(N, L) ->
  eqc_tree:tree(?MODULE, #{node => N, leaf => L}, tree).

grammar(Env) ->
  Tree = nonterminal(tree),
  #{ tree => 
       choice([
               {Tree, nat(), Tree},
               [1|2]
              ])}.

%% grammar(Env) ->
%%   Tree = nonterminal(tree),
%%   #{ tree => 
%%        choice([
%%                {Tree, maps:get(node, Env), Tree},
%%                maps:get(leaf, Env)
%%               ])}.


operator_tree() ->
  tree(elements(['and', 'or']), choose(0,1)).



