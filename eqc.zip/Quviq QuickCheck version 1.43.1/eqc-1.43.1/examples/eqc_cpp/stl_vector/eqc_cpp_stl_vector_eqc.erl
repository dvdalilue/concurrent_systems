-file("eqc-1.43.1/examples/eqc_cpp/stl_vector/eqc_cpp_stl_vector_eqc.erl", 0).
%%% File        : eqc_cpp_stl_vector_eqc.erl
%%% Author      : Hans Svensson
%%% Description : Testing STL vector implementation
%%% Created     : 15 Aug 2017 by Hans Svensson
-module(eqc_cpp_stl_vector_eqc).

-compile([export_all, nowarn_export_all]).

-file("eqc-1.43.1/examples/eqc_cpp/stl_vector/eqc_cpp_stl_vector_eqc.erl", 9).

-include_lib("eqc/include/eqc.hrl").
-include_lib("eqc/include/eqc_statem.hrl").

-define(SWG_FILE, "../examples/eqc_cpp/stl_vector/stl_vector.swg").

%% -- State ------------------------------------------------------------------

initial_state() -> [].

%% -- Generators -------------------------------------------------------------
gen_place() ->
  elements([first, last]).

gen_pos(Xs) ->
  choose(0, length(Xs) - 1).

%% -- Operations -------------------------------------------------------------

%% --- Operation: initialize ---
initialize_args(_Xs) -> [{var, vector}, nat(), int()].

initialize(V, N, Val) ->
  vector:'VectorInt_assign'(V, N, Val).

initialize_next(_Xs, _Value, [_, N, Val]) ->
  lists:duplicate(N, Val).

%% --- insert ---

insert_args(_Xs) -> [{var, vector}, gen_place(), int()].

insert(V, first, X) ->
  vector:'VectorInt_insert'(V, vector:'VectorInt_begin'(V), X);
insert(V, last, X) ->
  vector:'VectorInt_insert'(V, vector:'VectorInt_end'(V), X).

insert_next(Xs, _Value, [_V, first, X]) -> [X | Xs];
insert_next(Xs, _Value, [_V, last, X])  -> Xs ++ [X].

%% --- Operation: lookup ---
lookup_pre(Xs) -> Xs /= [].

lookup_args(Xs) -> [{var, vector}, gen_pos(Xs)].

lookup_pre(Xs, [_V, Pos]) -> length(Xs) > Pos.

lookup(V, Pos) -> vector:'VectorInt[]'(V, Pos).

lookup_post(Xs, [_V, Pos], Res) ->
  eq(eqc_c:deref(Res), lists:nth(Pos + 1, Xs)).

%% --- erase ---
erase_pre(Xs) -> Xs /= [].

erase_args(Xs) -> [{var, vector}, gen_pos(Xs)].

erase_pre(Xs, [_V, Pos]) -> length(Xs) > Pos.

erase(V, Pos) -> vector:'VectorInt_erase'(V, iterator_pos(V, Pos)).

erase_next(Xs, _Value, [_V, Pos]) ->
  element(1, do_erase(Xs, Pos)).

erase_post(Xs, [V, Pos], Res) ->
  case element(2, do_erase(Xs, Pos)) of
    undefined ->
      eq(vector:'VectorInt_iterator=='(Res, vector:'VectorInt_end'(V)), true);
    X ->
      eq(vector:'VectorInt_iterator*'(Res), X)
  end.

do_erase(Xs, Pos) ->
  {Pre, [_ | Post]} = lists:split(Pos, Xs),
  case Post of
    []      -> {Pre ++ Post, undefined};
    [X | _] -> {Pre ++ Post, X}
  end.


%% %% --- size ---

size_args(_) -> [{var, vector}].

size(V) -> vector:'VectorInt_size'(V).

size_post(Xs, [_V], Res) ->
  eq(Res, length(Xs)).

%% %% --- to_list ---

to_list_args(_) -> [{var, vector}].

to_list(V) -> iterate(vector:'VectorInt_begin'(V), vector:'VectorInt_end'(V)).

to_list_post(Xs, [_V], Res) ->
  eq(Res, Xs).

%% -- Common -----------------------------------------------------------------

iterate(I, End) -> iterate(I, End, []).

iterate(I, End, Acc) ->
  case vector:'VectorInt_iterator=='(I, End) of
    true  -> lists:reverse(Acc);
    false ->
      X = vector:'VectorInt_iterator*'(I),
      iterate(vector:'VectorInt_iterator++'(I), End, [X | Acc])
  end.

iterator_pos(V, Pos) ->
  iterator_pos1(vector:'VectorInt_begin'(V), Pos).

iterator_pos1(I, 0) -> I;
iterator_pos1(I, N) -> iterator_pos1(vector:'VectorInt_iterator++'(I), N - 1).

%% -- Property ---------------------------------------------------------------

%% The property.
prop_ok() -> prop_ok(?MODULE).
prop_ok(Mod) ->
  ?SETUP(fun() -> start(), fun() -> ok end end,
  ?FORALL(Cmds, commands(Mod),
  begin
    eqc_c:restart(),
    V = vector:'VectorInt_new'(),
    HSR={_, _, Res} = run_commands(Mod, Cmds, [{vector, V}]),
    pretty_commands(Mod, Cmds, HSR,
    check_command_names(Mod, Cmds, Res == ok))
  end)).

start() ->
  start([]).

start(ExtraOpts) ->
  eqc_cpp:start(vector, [{swig_file, ?SWG_FILE}, {cppflags, "-I."}] ++ ExtraOpts).


