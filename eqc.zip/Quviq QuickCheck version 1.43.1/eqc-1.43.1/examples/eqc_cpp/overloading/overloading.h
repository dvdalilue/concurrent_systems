class TmpInt {
  public:
    int b;
    TmpInt(int x): b(x){}
};

class Ovld {
  public:
    int a;

    Ovld(int x) : a(x) {}

    //Assign
    Ovld &operator =(const Ovld &x);

    //Add assign
    Ovld &operator +=(const Ovld &x);

    //Pre-increment
    Ovld &operator ++();

    //Post-increment
    Ovld operator ++(int dummy);

    //Unary plus
    Ovld operator +() const;

    //Binary plus
    Ovld operator +(const Ovld &x);

    //Logical not
    bool operator !() const;

    //Logical and
    bool operator &&(const Ovld &x) const;

    //Equal to
    bool operator ==(const Ovld &x) const;

    //Subscript
    int operator [](int ix);

    //Indirection
    int operator *();

    //Address of
    int *operator &();

    //Member of pointer
    TmpInt *operator ->();

};

