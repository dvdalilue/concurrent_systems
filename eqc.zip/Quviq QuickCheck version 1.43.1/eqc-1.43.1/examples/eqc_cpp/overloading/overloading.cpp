// Class/classes for testing overloading in eqc_cpp

#include "overloading.h"

// Many operators are similar enough that one example of that kind is enough...
//Assign
Ovld &Ovld::operator =(const Ovld &x){
  this->a = x.a;
  return *this;
}

//Add assign
Ovld &Ovld::operator +=(const Ovld &x){
  this->a += x.a;
  return *this;
}

//Pre-increment
Ovld &Ovld::operator ++(){
  this->a++;
  return *this;
}

//Post-increment
Ovld Ovld::operator ++(int dummy){
  Ovld *x = new Ovld(this->a);
  this->a++;
  return *x;
}

//Unary plus
Ovld Ovld::operator +() const{
  Ovld *x = new Ovld(this->a);
  return *x;
}

//Binary plus
Ovld Ovld::operator +(const Ovld &x){
  Ovld *y = new Ovld(this->a + x.a);
  return *y;
}

//Logical not
bool Ovld::operator !() const {
  return this->a < 0;
}

//Logical and
bool Ovld::operator &&(const Ovld &x) const {
  return this->a >= 0 && x.a >= 0;
}

//Equal to
bool Ovld::operator ==(const Ovld &x) const {
  return this->a == x.a;
}

//Subscript
int Ovld::operator [](int ix){
  return (this->a << ix) & 1;
}

//Indirection
int Ovld::operator *() {
  return this->a;
}

//Address of
int *Ovld::operator &() {
  return &this->a;
}

//Member of pointer
TmpInt *Ovld::operator ->() {
  TmpInt *x = new TmpInt(this->a);
  return x;
}


